//! Alignment record and fields.

pub mod record;

pub use self::record::Record;
