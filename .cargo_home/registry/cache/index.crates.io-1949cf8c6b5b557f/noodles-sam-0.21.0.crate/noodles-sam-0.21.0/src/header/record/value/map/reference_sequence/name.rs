//! SAM header reference sequence name.

pub use crate::record::reference_sequence_name::ParseError;

/// A reference sequence name.
pub type Name = crate::record::ReferenceSequenceName;
