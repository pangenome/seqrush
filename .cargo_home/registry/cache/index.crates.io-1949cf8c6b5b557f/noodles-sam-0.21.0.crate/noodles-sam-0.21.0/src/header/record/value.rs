//! SAM header record value.

pub mod map;

pub use self::map::Map;
