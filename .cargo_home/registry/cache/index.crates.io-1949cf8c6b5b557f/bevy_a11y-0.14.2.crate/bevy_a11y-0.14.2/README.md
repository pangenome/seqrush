# Bevy A11Y (Accessibility)

[![License](https://img.shields.io/badge/license-MIT%2FApache-blue.svg)](https://github.com/bevyengine/bevy#license)
[![Crates.io](https://img.shields.io/crates/v/bevy_a11y.svg)](https://crates.io/crates/bevy_a11y)
[![Downloads](https://img.shields.io/crates/d/bevy_a11y.svg)](https://crates.io/crates/bevy_a11y)
[![Docs](https://docs.rs/bevy_a11y/badge.svg)](https://docs.rs/bevy_a11y/latest/bevy_a11y/)
[![Discord](https://img.shields.io/discord/691052431525675048.svg?label=&logo=discord&logoColor=ffffff&color=7389D8&labelColor=6A7EC2)](https://discord.gg/bevy)
