use encase::ShaderType;

fn main() {}

#[derive(ShaderType)]
struct Test;
