# Bevy Math

[![License](https://img.shields.io/badge/license-MIT%2FApache-blue.svg)](https://github.com/bevyengine/bevy#license)
[![Crates.io](https://img.shields.io/crates/v/bevy_math.svg)](https://crates.io/crates/bevy_math)
[![Downloads](https://img.shields.io/crates/d/bevy_math.svg)](https://crates.io/crates/bevy_math)
[![Docs](https://docs.rs/bevy_math/badge.svg)](https://docs.rs/bevy_math/latest/bevy_math/)
[![Discord](https://img.shields.io/discord/691052431525675048.svg?label=&logo=discord&logoColor=ffffff&color=7389D8&labelColor=6A7EC2)](https://discord.gg/bevy)
