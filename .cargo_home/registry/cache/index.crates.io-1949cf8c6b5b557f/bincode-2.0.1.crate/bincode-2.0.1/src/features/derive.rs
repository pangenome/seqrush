#[cfg_attr(docsrs, doc(cfg(feature = "derive")))]
pub use bincode_derive::{BorrowDecode, Decode, Encode};
