# vecto

smol rust lib for `Vector2`.

- is generic over floats
- has methods
- overloads operators

## usage

```rust
use vecto::Vec2;
let v = Vec2::splat(5.0);
```