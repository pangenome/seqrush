//! An empty application (does nothing)

use bevy::prelude::*;

fn main() {
    App::new().run();
}
