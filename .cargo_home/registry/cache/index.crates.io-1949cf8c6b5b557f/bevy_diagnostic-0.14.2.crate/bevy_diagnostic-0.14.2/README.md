# Bevy Diagnostic

[![License](https://img.shields.io/badge/license-MIT%2FApache-blue.svg)](https://github.com/bevyengine/bevy#license)
[![Crates.io](https://img.shields.io/crates/v/bevy_diagnostic.svg)](https://crates.io/crates/bevy_diagnostic)
[![Downloads](https://img.shields.io/crates/d/bevy_diagnostic.svg)](https://crates.io/crates/bevy_diagnostic)
[![Docs](https://docs.rs/bevy_diagnostic/badge.svg)](https://docs.rs/bevy_diagnostic/latest/bevy_diagnostic/)
[![Discord](https://img.shields.io/discord/691052431525675048.svg?label=&logo=discord&logoColor=ffffff&color=7389D8&labelColor=6A7EC2)](https://discord.gg/bevy)
