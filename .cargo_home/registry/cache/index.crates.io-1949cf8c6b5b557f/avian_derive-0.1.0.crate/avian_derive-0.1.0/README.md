# `avian_derive`

This crate provides some derive implementation for [Avian Physics](https://github.com/Jondolf/avian).
