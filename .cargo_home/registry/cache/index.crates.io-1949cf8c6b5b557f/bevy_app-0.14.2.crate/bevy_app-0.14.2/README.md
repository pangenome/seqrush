# Bevy App

[![License](https://img.shields.io/badge/license-MIT%2FApache-blue.svg)](https://github.com/bevyengine/bevy#license)
[![Crates.io](https://img.shields.io/crates/v/bevy.svg)](https://crates.io/crates/bevy_app)
[![Downloads](https://img.shields.io/crates/d/bevy_app.svg)](https://crates.io/crates/bevy_app)
[![Docs](https://docs.rs/bevy_app/badge.svg)](https://docs.rs/bevy_app/latest/bevy_app/)
[![Discord](https://img.shields.io/discord/691052431525675048.svg?label=&logo=discord&logoColor=ffffff&color=7389D8&labelColor=6A7EC2)](https://discord.gg/bevy)

This crate is about everything concerning the highest-level, application layer of a [Bevy](https://crates.io/crates/bevy) app.
