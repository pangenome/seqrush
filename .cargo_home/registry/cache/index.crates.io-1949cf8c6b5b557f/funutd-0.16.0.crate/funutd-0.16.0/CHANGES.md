# Changes

## Version 0.12

- Palette generator was rewritten. It produces more pleasing and varied palettes now.
