#!/bin/sh
printf '%s' "$1" 2>&1
