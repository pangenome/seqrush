Procedural Macros for Plugins
=============================

![Rhai logo](https://rhai.rs/book/images/logo/rhai-banner-transparent-colour.svg)

This crate holds procedural macros for code generation, supporting the plugins system
for [Rhai](https://github.com/rhaiscript/rhai).

This crate is automatically referenced by the [Rhai crate](https://crates.io/crates/rhai).
Normally it should not be used directly.
