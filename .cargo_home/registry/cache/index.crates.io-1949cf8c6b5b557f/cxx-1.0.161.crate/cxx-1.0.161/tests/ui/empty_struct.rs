#[cxx::bridge]
mod ffi {
    struct Empty {}
}

fn main() {}
