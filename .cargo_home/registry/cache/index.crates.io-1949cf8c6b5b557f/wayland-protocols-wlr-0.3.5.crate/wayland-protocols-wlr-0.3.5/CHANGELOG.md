# CHANGELOG: wayland-protocols-wlr

## Unreleased

## 0.3.4 -- 2024-09-04

- Update wlr-protocols
  - `wlr-layer-shell-unstable-v1` is now version 5, with option to set exclusion edge

## 0.3.0 -- 2024-05-30

### Breaking changes
- Updated wayland-protocols to 0.3

## 0.2.0 -- 2023-09-02

### Breaking changes

- Bump bitflags to 2.0
- Updated wayland-backend to 0.3

## 0.1.0 -- 27/12/2022

## 0.1.0-beta.14

### Additions

- Update wlr-protocols
  - `wlr-output-management-unstable-v1` is now version 4, allowing to change the adaptive sync state
