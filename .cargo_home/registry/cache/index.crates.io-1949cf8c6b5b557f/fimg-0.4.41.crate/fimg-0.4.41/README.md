# fimg

quick simple image operations

## supported operations

- [x] overlay
- [x] rotation
- [x] flipping
- [x] image tiling
- [x] image scaling
- [x] triangle drawing
- [x] line drawing
- [x] box drawing
- [x] polygon drawing
- [x] circle drawing
- [x] text drawing
- [x] blur