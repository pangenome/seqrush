pub fn dimensions() -> Option<(usize, usize)> { None }
pub fn dimensions_stdout() -> Option<(usize, usize)> { None }
pub fn dimensions_stdin() -> Option<(usize, usize)> { None }
pub fn dimensions_stderr() -> Option<(usize, usize)> { None }
