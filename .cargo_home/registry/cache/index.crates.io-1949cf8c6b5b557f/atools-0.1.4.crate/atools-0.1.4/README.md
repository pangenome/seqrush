# atools

const generic expr based fixed length array manipulation crate

it is very nightly.