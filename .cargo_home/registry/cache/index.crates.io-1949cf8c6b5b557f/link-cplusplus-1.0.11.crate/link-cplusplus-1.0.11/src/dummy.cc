#ifdef __clang__
#pragma clang diagnostic ignored "-Wmissing-variable-declarations"
#endif

int rust_link_cplusplus;
