# fer

this is fast_image_resize but with 100% more ub