//! Composable iterators for alignment records.

mod pileup;

pub use self::pileup::Pileup as Depth;
