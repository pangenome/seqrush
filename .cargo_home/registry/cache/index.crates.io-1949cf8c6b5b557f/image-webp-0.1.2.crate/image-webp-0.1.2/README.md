# image-webp

[![crates.io](https://img.shields.io/crates/v/image-webp.svg)](https://crates.io/crates/image-webp)
[![Documentation](https://docs.rs/image-webp/badge.svg)](https://docs.rs/image-webp)
[![Build Status](https://github.com/image-rs/image-webp/workflows/Rust%20CI/badge.svg)](https://github.com/image-rs/image-webp/actions)

WebP encoding and decoding in pure Rust
