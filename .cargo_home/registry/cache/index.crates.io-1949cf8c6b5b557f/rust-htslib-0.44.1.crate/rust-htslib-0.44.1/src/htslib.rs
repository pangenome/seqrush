//! Re-export hts-sys htslib bindings
pub use hts_sys::*;
