# `cursor-icon`: A common cursor icon type

This library provides standard type to work with the cursor icon accross
multiple platforms.

The transformation to the actual value used by the platform for this icon is
left to the libraries like https://github.com/rust-windowing/winit.
