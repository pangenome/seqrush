//! Async gzip index I/O.

mod reader;
mod writer;

pub use self::{reader::Reader, writer::Writer};
