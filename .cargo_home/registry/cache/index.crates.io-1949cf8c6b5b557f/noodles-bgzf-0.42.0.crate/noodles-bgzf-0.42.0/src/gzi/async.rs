//! Async gzip index.

pub mod fs;
pub mod io;
