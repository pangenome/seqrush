//! Async BGZF.

mod block_codec;
pub mod io;

use self::block_codec::BlockCodec;
