# Safety

Refer to [`Self`]'s safety documentation.
This function is unsafe only when used with a [`FFloat`]; Calling it with a [`f64`] or a [`f32`] is safe.