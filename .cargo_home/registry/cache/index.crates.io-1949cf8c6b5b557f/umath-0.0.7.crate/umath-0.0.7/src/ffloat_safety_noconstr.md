# Safety

- You MUST NEVER turn the produced [`FFloat`] into [`NAN`] | [`INF`]
- You MUST NEVER combine this [`FFloat`] with another {[`FFloat`], [`f32`], [`f64`]}, to produce a [`NAN`] | [`INF`]