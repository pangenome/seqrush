Please note that calling this function may (although its dependent on the function) incur UB.

These functions are not marked `unsafe`, as the entire [`FFloat`] type is essentially unsafe.