# libdeflate-sys 

Raw C bindings to [libdeflate](https://github.com/ebiggers/libdeflate).

Used by [libdeflater](https://crates.io/crates/libdeflater), which
exposes safer Rust bindings to the library.
