#pragma once

namespace rust {
inline namespace cxxbridge1 {
namespace {
template <typename T>
class impl;
} // namespace
} // namespace cxxbridge1
} // namespace rust
