#pragma once
#include "../../../include/cxx.h"

namespace rust {
inline namespace cxxbridge1 {
class Str::uninit {};
//
inline Str::Str(uninit) noexcept {}
} // namespace cxxbridge1
} // namespace rust
