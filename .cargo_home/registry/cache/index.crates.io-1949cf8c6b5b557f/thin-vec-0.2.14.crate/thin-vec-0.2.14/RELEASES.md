# Version 0.2.14 (2025-02-19)
* Add "malloc_size_of" feature for heap size measurement support

# Version 0.2.13 (2023-12-02)

* add default-on "std" feature for no_std support
* added has_capacity method for checking if something is the empty singleton
* marked more things as `#[inline]`
* added license files
* appeased clippy

# Previous Versions

*shrug*