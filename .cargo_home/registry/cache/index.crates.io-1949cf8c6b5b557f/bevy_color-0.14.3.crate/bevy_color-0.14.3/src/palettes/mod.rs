//! Color palettes consisting of collections of const colors.

pub mod basic;
pub mod css;
pub mod tailwind;
