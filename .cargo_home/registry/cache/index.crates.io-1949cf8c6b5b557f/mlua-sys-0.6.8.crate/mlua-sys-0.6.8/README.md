# mlua-sys

Low level (FFI) bindings to Lua 5.4/5.3/5.2/5.1 (including LuaJIT) and [Luau].

Intended to be consumed by the [mlua] crate.

[Luau]: https://github.com/luau-lang/luau
[mlua]: https://crates.io/crates/mlua
