# anstyle-query

> **Low level terminal capability lookups**

[![Documentation](https://img.shields.io/badge/docs-master-blue.svg)][Documentation]
![License](https://img.shields.io/crates/l/anstyle-query.svg)
[![Crates Status](https://img.shields.io/crates/v/anstyle-query.svg)](https://crates.io/crates/anstyle-query)

## [Contribute](../../CONTRIBUTING.md)

## License

Dual-licensed under [MIT](../../LICENSE-MIT) or [Apache 2.0](../../LICENSE-APACHE)

[Documentation]: https://docs.rs/anstyle-query
