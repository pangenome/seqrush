//! core components and types used throughout this library

/// Counter type defining operations required by the histogram and impls for primitives.
pub mod counter;
