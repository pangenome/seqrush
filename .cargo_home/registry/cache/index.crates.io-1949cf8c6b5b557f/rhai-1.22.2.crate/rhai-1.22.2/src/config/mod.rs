//! Configuration for Rhai.

pub mod hashing;
mod hashing_env;
