//! This file is automatically recreated during build time by `build.rs` from `build.template`.

pub const HASHING_SEED: Option<[u64; 4]> = None;
