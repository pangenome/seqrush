# (glsl)pp-rs

<!-- Some Matrix channel, like Naga's? -->
[![Crates.io](https://img.shields.io/crates/v/pp-rs.svg?label=pp-rs)](https://crates.io/crates/pp-rs)
[![Docs.rs](https://docs.rs/pp-rs/badge.svg)](https://docs.rs/pp-rs)
[![Build Status](https://github.com/Kangz/glslpp-rs/workflows/pipeline/badge.svg)](https://github.com/Kangz/glslpp-rs/actions)
[![codecov](https://codecov.io/gh/Kangz/glslpp-rs/branch/main/graph/badge.svg?token=CMM90W97YO)](https://codecov.io/gh/Kangz/glslpp-rs)


A shader preprocessor and lexer in Rust.

**WARNING**: this crate is a work-in-progress: its interface will change and documentation is extremely lacking.