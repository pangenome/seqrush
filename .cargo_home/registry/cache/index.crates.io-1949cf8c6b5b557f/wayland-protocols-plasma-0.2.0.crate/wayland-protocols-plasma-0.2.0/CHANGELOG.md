# CHANGELOG: wayland-protocols-plasma

## Unreleased

## 0.2.0 -- 2023-09-02

### Breaking changes

- Bump bitflags to 2.0
- Updated wayland-backend to 0.3

### Additions

- Introduce protocol `kde-plasma-window-management`.

## 0.1.0 -- 27/12/2022
