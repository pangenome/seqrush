//! Various utilities used by the `zvariant` crate and others.

pub mod case;
pub mod macros;
