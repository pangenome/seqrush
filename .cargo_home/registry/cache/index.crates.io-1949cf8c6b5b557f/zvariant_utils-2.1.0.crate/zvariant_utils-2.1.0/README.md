# zvariant_utils

[![](https://docs.rs/zvariant_utils/badge.svg)](https://docs.rs/zvariant_utils/) [![](https://img.shields.io/crates/v/zvariant_utils)](https://crates.io/crates/zvariant_utils)

This crate provides various utilities for [`zvariant`].

## Stability

The API is NOT expected to be stable. The crate, however, will follow semver rules: breaking changes would cause a major version bump.

[`zvariant`]: https://crates.io/crates/zvariant
