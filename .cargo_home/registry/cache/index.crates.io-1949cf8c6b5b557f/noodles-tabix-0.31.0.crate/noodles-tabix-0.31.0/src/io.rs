//! Tabix I/O.

pub mod indexed_reader;
