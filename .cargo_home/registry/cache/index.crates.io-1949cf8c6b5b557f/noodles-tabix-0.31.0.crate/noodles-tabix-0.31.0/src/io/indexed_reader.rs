//! Tabix indexed reader.

mod builder;

pub use self::builder::Builder;
