This directory contains the container setup used when developing CXX inside of
GitHub [Codespaces].

[Codespaces]: https://github.com/features/codespaces
