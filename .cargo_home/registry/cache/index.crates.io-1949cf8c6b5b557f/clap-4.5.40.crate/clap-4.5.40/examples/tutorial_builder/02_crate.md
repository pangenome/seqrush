```console
$ 02_crate --help
A simple to use, efficient, and full-featured Command Line Argument Parser

Usage: 02_crate[EXE] --two <VALUE> --one <VALUE>

Options:
      --two <VALUE>  
      --one <VALUE>  
  -h, --help         Print help
  -V, --version      Print version

$ 02_crate --version
clap [..]

```
