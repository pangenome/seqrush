---
name: Feature Request
about: Suggest a way ktx2 could be better.
title: ''
labels: enhancement
assignees: ''
---

## Description
<!--A description of what the problem is-->

## Proposed Solution
<!--A description of what you want to happen-->

## Alternatives
<!--Any alternative solutions or features you've considered-->

## Additional context
<!--Add any other context about the feature request here-->