---
name: Bug Report
about: ktx2 malfunctioning? Please provide a detailed bug report.
title: ''
labels: bug
assignees: ''
---

<!--Thank you for filing this! Please provide as much information as possible to help us diagnose and fix the issue-->

## Description
<!--A clear and concise description of what the bug is-->

## Repro steps
<!--A runable example or short code sample showing how to reproduce the bug-->

## Extra Materials
<!--Anything that could help us diagnose or fix the issue-->

## System Information
<!--Version of ktx2, information about your OS if relevant, your tech stack, etc.-->
