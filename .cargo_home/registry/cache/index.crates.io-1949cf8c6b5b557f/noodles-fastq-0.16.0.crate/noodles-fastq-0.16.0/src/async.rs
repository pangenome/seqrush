//! Async FASTQ.

pub mod io;
