//! Sequence format.

pub mod record;

pub use self::record::Record;
