//! Async FAI.

pub mod io;
