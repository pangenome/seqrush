//! Async FAI I/O.

mod reader;

pub use self::reader::Reader;
