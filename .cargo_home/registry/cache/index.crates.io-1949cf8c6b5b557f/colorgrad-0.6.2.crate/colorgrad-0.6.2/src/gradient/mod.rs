pub(crate) mod basis;
pub(crate) mod catmull_rom;
pub(crate) mod gimp;
pub(crate) mod linear;
pub(crate) mod preset;
pub(crate) mod sharp;
