RUSTFLAGS="--emit llvm-ir,asm" cargo build --release
