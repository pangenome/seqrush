
# bytemuck_derive

Derive macros for [bytemuck](https://docs.rs/bytemuck) traits.

MSRV: None!

This is an opt-in bonus feature for `bytemuck` that doesn't particularly do
anything you couldn't do yourself, and so MSRV is not a strong consideration for
this crate.
