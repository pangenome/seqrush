# Contributing
Code and documentation PRs are always welcome. Just remember to list out introduced changes. 

If you want to suggest some improvements, report a bug, discuss a functionality, etc., feel free to open an issue.
