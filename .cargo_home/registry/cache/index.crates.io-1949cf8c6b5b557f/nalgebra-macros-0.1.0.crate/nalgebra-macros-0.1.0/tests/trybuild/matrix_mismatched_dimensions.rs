use nalgebra_macros::matrix;

fn main() {
    matrix![1, 2, 3;
            4, 5];
}