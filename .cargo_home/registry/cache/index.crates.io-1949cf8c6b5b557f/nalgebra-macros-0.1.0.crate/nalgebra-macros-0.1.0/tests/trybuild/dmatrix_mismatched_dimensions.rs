use nalgebra_macros::dmatrix;

fn main() {
    dmatrix![1, 2, 3;
            4, 5];
}