[![Crates.io](https://img.shields.io/crates/d/bio-types.svg)](https://crates.io/crates/bio-types)
[![Crates.io](https://img.shields.io/crates/v/bio-types.svg)](https://crates.io/crates/bio-types)
[![Crates.io](https://img.shields.io/crates/l/bio-types.svg)](https://crates.io/crates/bio-types)
[![GitHub Workflow Status](https://github.com/rust-bio/rust-bio-types/actions/workflows/rust.yml/badge.svg?branch=master)](https://github.com/rust-bio/rust-bio-types/actions/workflows/rust.yml)
[![Coverage Status](https://coveralls.io/repos/github/rust-bio/rust-bio-types/badge.svg?branch=master)](https://coveralls.io/github/rust-bio/rust-bio-types?branch=master)

# Rust-Bio-Types

This crate provides common biomedical types that will be used by rust-bio and rust-htslib. Feel free to provide additional types as needed.
