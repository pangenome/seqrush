# varbincode

varbincode is a binary serialization format that uses variable length encoding
for integer values, which typically results in reduced size of the encoded
data.

It is losely based on the `bincode` crate which is offered under an MIT license
(same as the wezterm crate from which `varbincode` originates) and is Copyright
2014 Ty Overby.
