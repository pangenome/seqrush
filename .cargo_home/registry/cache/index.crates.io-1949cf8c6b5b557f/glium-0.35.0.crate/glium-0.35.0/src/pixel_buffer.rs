//! Moved to the `texture` module.
#![deprecated(note = "Moved to the `texture` module")]
pub use crate::texture::pixel_buffer::*;
