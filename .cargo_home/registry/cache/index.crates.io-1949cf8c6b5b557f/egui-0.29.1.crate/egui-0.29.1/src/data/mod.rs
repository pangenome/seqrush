//! All the data sent between egui and the backend

pub mod input;
mod key;
pub mod output;

pub use key::Key;
