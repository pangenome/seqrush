# euclid

This is a small library for geometric types with a focus on 2d graphics and
layout.

* [Documentation](https://docs.rs/euclid/)
* [Release notes](https://github.com/servo/euclid/releases)
* [crates.io](https://crates.io/crates/euclid)
