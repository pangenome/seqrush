# Bevy Log

[![License](https://img.shields.io/badge/license-MIT%2FApache-blue.svg)](https://github.com/bevyengine/bevy#license)
[![Crates.io](https://img.shields.io/crates/v/bevy_log.svg)](https://crates.io/crates/bevy_log)
[![Downloads](https://img.shields.io/crates/d/bevy_log.svg)](https://crates.io/crates/bevy_log)
[![Docs](https://docs.rs/bevy_log/badge.svg)](https://docs.rs/bevy_log/latest/bevy_log/)
[![Discord](https://img.shields.io/discord/691052431525675048.svg?label=&logo=discord&logoColor=ffffff&color=7389D8&labelColor=6A7EC2)](https://discord.gg/bevy)
