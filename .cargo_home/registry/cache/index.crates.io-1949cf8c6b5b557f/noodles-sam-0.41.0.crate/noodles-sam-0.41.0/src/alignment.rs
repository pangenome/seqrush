//! Alignment record and fields.

pub mod iter;
pub mod record;

pub use self::record::Record;
