//! Lazily-evaluated SAM record and fields.

mod record;

pub use self::record::Record;
