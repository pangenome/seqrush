encase_derive_impl::implement!(encase_derive_impl::syn::parse_quote!(::encase));
