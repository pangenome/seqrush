//! Lazily-evaluated VCF record.

pub mod record;

pub use self::record::Record;
